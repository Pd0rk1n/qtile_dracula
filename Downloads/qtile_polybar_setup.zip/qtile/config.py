from libqtile import layout, hook
from libqtile.config import Key, Group, Screen
from libqtile.lazy import lazy

mod = "mod4"

keys = [
    Key([mod], "Return", lazy.spawn("alacritty")),
    Key([mod], "d", lazy.spawn("rofi -show drun")),
    Key([mod], "q", lazy.window.kill()),
    Key([mod, "control"], "r", lazy.restart()),
]

groups = [Group(i) for i in "123456789"]
for i in groups:
    keys.extend([
        Key([mod], i.name, lazy.group[i.name].toscreen()),
        Key([mod, "shift"], i.name, lazy.window.togroup(i.name)),
    ])

layouts = [layout.MonadTall(), layout.Max()]

@hook.subscribe.startup_once
def autostart():
    import subprocess
    subprocess.Popen(["~/.config/polybar/launch.sh"])

floating_layout = layout.Floating()
