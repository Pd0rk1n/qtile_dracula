#!/bin/bash
# This will be replaced with the real bootstrap script
