#!/bin/bash
pkill polybar
sleep 1
MONITOR=$(xrandr --query | grep " connected" | cut -d" " -f1 | head -n1)
polybar -c ~/.config/polybar/config.ini qtilebar &
